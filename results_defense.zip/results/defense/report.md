**Clean performance on the test set**

| Model | APCER (fakes accepted) | BPCER (real rejected) | ACER |
|---|---|---|---|
| Baseline (no defense) | 28.8% ± 8.7 | 1.3% ± 0.9 | 15.1% ± 3.9 |
| Adversarial fine-tuning at 2/255 | 45.0% ± 0.8 | 6.4% ± 1.5 | 25.7% ± 0.7 |

**Robustness (lower is better in every column)**

| Model | Attack success (8/255, 10 steps) | Attack success (stronger: 16/255, 40 steps) | Fakes accepted under random noise (control) | Real faces rejected after attack | Worst case (fake fools it clean OR under any attack) |
|---|---|---|---|---|---|
| Baseline (no defense) | 100.0% ± 0.0 | 100.0% ± 0.0 | 27.2% ± 10.4 | 100.0% ± 0.0 | 100.0% ± 0.0 |
| Adversarial fine-tuning at 2/255 | 97.7% ± 0.4 | 100.0% ± 0.0 | 46.2% ± 0.9 | 98.8% ± 0.8 | 100.0% ± 0.0 |

**Validation vs test accuracy**

| Model | Accuracy on validation | Accuracy on test |
|---|---|---|
| Baseline (no defense) | 98.6% ± 0.3 | 84.9% ± 3.9 |
| Adversarial fine-tuning at 2/255 | 92.9% ± 0.6 | 74.3% ± 0.7 |

**Attack success vs attack budget (10 steps)**

| Model | 1/255 | 2/255 | 4/255 | 8/255 | 16/255 |
|---|---|---|---|---|---|
| Baseline (no defense) | 100.0% ± 0.0 | 100.0% ± 0.0 | 100.0% ± 0.0 | 100.0% ± 0.0 | 100.0% ± 0.0 |
| Adversarial fine-tuning at 2/255 | 52.4% ± 1.3 | 62.6% ± 2.1 | 80.5% ± 1.3 | 97.8% ± 0.5 | 100.0% ± 0.0 |

**Attack success on fakes the model caught WITHOUT an attack (10 steps)**

| Model | 1/255 | 2/255 | 4/255 | 8/255 | 16/255 |
|---|---|---|---|---|---|
| Baseline (no defense) | 100.0% ± 0.0 | 100.0% ± 0.0 | 100.0% ± 0.0 | 100.0% ± 0.0 | 100.0% ± 0.0 |
| Adversarial fine-tuning at 2/255 | 13.4% ± 2.1 | 32.0% ± 3.4 | 64.6% ± 1.9 | 96.0% ± 0.9 | 100.0% ± 0.0 |
